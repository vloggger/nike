module.exports = {
    extend: '@vuepress/theme-default',
};
